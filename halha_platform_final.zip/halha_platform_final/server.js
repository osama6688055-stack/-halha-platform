const express=require('express');
const cors=require('cors');
const helmet=require('helmet');
const rateLimit=require('express-rate-limit');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const Database=require('better-sqlite3');
const path=require('path');
const app=express();
const PORT=process.env.PORT||3000;
const SECRET=process.env.JWT_SECRET||'CHANGE_THIS_SECRET_IN_PRODUCTION';
app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:process.env.CORS_ORIGIN||true}));
app.use(express.json({limit:'1mb'}));
app.use('/api/login', rateLimit({windowMs:15*60*1000, max:30, standardHeaders:true, legacyHeaders:false}));
const publicDir=path.join(__dirname,'public');
app.use(express.static(publicDir));
const db=new Database(process.env.DB_FILE||path.join(__dirname,'halha.db'));
db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,mobile TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','customer','provider')),category TEXT,active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS wallets(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER UNIQUE NOT NULL,balance REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,request_id INTEGER,type TEXT NOT NULL,amount REAL NOT NULL,description TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS offers(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id INTEGER NOT NULL,provider_id INTEGER NOT NULL,amount REAL NOT NULL,note TEXT,accepted INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(request_id,provider_id));
CREATE TABLE IF NOT EXISTS requests(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER NOT NULL,category_id INTEGER NOT NULL,title TEXT NOT NULL,description TEXT,location TEXT,status TEXT DEFAULT 'new',provider_id INTEGER,price REAL DEFAULT 0,commission REAL DEFAULT 0,provider_earning REAL DEFAULT 0,payment_status TEXT DEFAULT 'unpaid',rating INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
function ensureWallet(userId){db.prepare('INSERT OR IGNORE INTO wallets(user_id,balance) VALUES(?,0)').run(userId)}
function seed(){
 const count=db.prepare('SELECT COUNT(*) n FROM users').get().n;
 if(!count){
  const ins=db.prepare('INSERT INTO users(name,mobile,password,role,category) VALUES(?,?,?,?,?)');
  ins.run('مدير النظام','01000000000',bcrypt.hashSync('1234',10),'admin',null);
  ins.run('أحمد العميل','01011111111',bcrypt.hashSync('1234',10),'customer',null);
  ins.run('محمود للسباكة','01022222222',bcrypt.hashSync('1234',10),'provider','سباكة');
 }
 db.prepare('SELECT id FROM users').all().forEach(u=>ensureWallet(u.id));
 if(!db.prepare('SELECT COUNT(*) n FROM categories').get().n){
  const ins=db.prepare('INSERT INTO categories(name) VALUES(?)');
  ['سباكة','كهرباء','تكييف','أجهزة منزلية','نظافة','نجارة'].forEach(x=>ins.run(x));
 }
}
seed();
function auth(req,res,next){try{const token=(req.headers.authorization||'').replace(/^Bearer\s+/,'');req.user=jwt.verify(token,SECRET);next()}catch(e){res.status(401).json({error:'غير مصرح'})}}
function admin(req,res,next){if(req.user.role!=='admin')return res.status(403).json({error:'المدير فقط'});next()}
function role(...roles){return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:'ليس لديك صلاحية'})}
app.post('/api/register',(req,res)=>{const {name,mobile,password,role='customer',category}=req.body;if(!name||!mobile||!password||!['customer','provider'].includes(role))return res.status(400).json({error:'بيانات التسجيل غير مكتملة'});try{const r=db.prepare('INSERT INTO users(name,mobile,password,role,category) VALUES(?,?,?,?,?)').run(name,mobile,bcrypt.hashSync(password,10),role,category||null);res.json({id:r.lastInsertRowid})}catch(e){res.status(409).json({error:'رقم الهاتف مستخدم بالفعل'})}});
app.post('/api/login',(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE mobile=? AND active=1').get(req.body.mobile);if(!u||!bcrypt.compareSync(req.body.password||'',u.password))return res.status(401).json({error:'بيانات الدخول غير صحيحة'});const token=jwt.sign({id:u.id,name:u.name,role:u.role},SECRET,{expiresIn:'7d'});res.json({token,user:{id:u.id,name:u.name,mobile:u.mobile,role:u.role,category:u.category}})});
app.get('/api/me',auth,(req,res)=>{const u=db.prepare('SELECT id,name,mobile,role,category,active,created_at FROM users WHERE id=?').get(req.user.id);res.json(u)});
app.get('/api/categories',auth,(req,res)=>res.json(db.prepare('SELECT * FROM categories WHERE active=1 ORDER BY id').all()));
app.post('/api/categories',auth,admin,(req,res)=>{try{const r=db.prepare('INSERT INTO categories(name) VALUES(?)').run(req.body.name);res.json({id:r.lastInsertRowid})}catch(e){res.status(409).json({error:'الخدمة موجودة بالفعل'})}});
app.delete('/api/categories/:id',auth,admin,(req,res)=>{db.prepare('UPDATE categories SET active=0 WHERE id=?').run(req.params.id);res.json({ok:true})});
app.get('/api/providers',auth,admin,(req,res)=>res.json(db.prepare("SELECT id,name,mobile,category,active,created_at FROM users WHERE role='provider' ORDER BY id DESC").all()));
app.post('/api/providers',auth,admin,(req,res)=>{const {name,mobile,password='1234',category}=req.body;if(!name||!mobile)return res.status(400).json({error:'بيانات ناقصة'});try{const r=db.prepare('INSERT INTO users(name,mobile,password,role,category) VALUES(?,?,?,?,?)').run(name,mobile,bcrypt.hashSync(password,10),'provider',category||null);res.json({id:r.lastInsertRowid})}catch(e){res.status(409).json({error:'رقم الهاتف مستخدم بالفعل'})}});
app.get('/api/customers',auth,admin,(req,res)=>res.json(db.prepare("SELECT u.id,u.name,u.mobile,u.created_at,COUNT(r.id) requests FROM users u LEFT JOIN requests r ON r.customer_id=u.id WHERE u.role='customer' GROUP BY u.id ORDER BY u.id DESC").all()));
app.post('/api/requests',auth,role('customer'),(req,res)=>{const {category_id,title,description='',location=''}=req.body;if(!category_id||!title)return res.status(400).json({error:'نوع الخدمة والعنوان مطلوبان'});const r=db.prepare('INSERT INTO requests(customer_id,category_id,title,description,location) VALUES(?,?,?,?,?)').run(req.user.id,category_id,title,description,location);res.json({id:r.lastInsertRowid})});
const requestSelect=`SELECT r.*,c.name category,cu.name customer,cu.mobile customer_mobile,p.name provider,p.mobile provider_mobile FROM requests r JOIN categories c ON c.id=r.category_id JOIN users cu ON cu.id=r.customer_id LEFT JOIN users p ON p.id=r.provider_id`;
app.get('/api/requests',auth,(req,res)=>{let sql=requestSelect,params=[];if(req.user.role==='customer'){sql+=' WHERE r.customer_id=?';params=[req.user.id]}else if(req.user.role==='provider'){sql+=' WHERE r.provider_id IS NULL OR r.provider_id=?';params=[req.user.id]}sql+=' ORDER BY r.id DESC';res.json(db.prepare(sql).all(...params))});
app.post('/api/requests/:id/price',auth,admin,(req,res)=>{const price=Number(req.body.price);const rate=Number(req.body.commission_rate??10);if(!Number.isFinite(price)||price<0||!Number.isFinite(rate)||rate<0||rate>100)return res.status(400).json({error:'السعر أو العمولة غير صحيحة'});const commission=Number((price*rate/100).toFixed(2));const earning=Number((price-commission).toFixed(2));const r=db.prepare("UPDATE requests SET price=?,commission=?,provider_earning=?,payment_status='pending',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(price,commission,earning,req.params.id);res.json({ok:r.changes>0,price,commission,provider_earning:earning})});
app.post('/api/requests/:id/pay',auth,role('customer'),(req,res)=>{const r=db.prepare("UPDATE requests SET payment_status='paid',updated_at=CURRENT_TIMESTAMP WHERE id=? AND customer_id=? AND status='completed' AND payment_status!='paid'").run(req.params.id,req.user.id);if(!r.changes)return res.status(400).json({error:'لا يمكن الدفع قبل إتمام الخدمة أو تم الدفع بالفعل'});const x=db.prepare('SELECT provider_id,provider_earning FROM requests WHERE id=?').get(req.params.id);if(x.provider_id){ensureWallet(x.provider_id);db.prepare('UPDATE wallets SET balance=balance+? WHERE user_id=?').run(x.provider_earning,x.provider_id);db.prepare('INSERT INTO transactions(user_id,request_id,type,amount,description) VALUES(?,?,?,?,?)').run(x.provider_id,req.params.id,'earning',x.provider_earning,'أرباح خدمة')}res.json({ok:true})});
app.get('/api/wallet',auth,role('provider'),(req,res)=>{ensureWallet(req.user.id);res.json({wallet:db.prepare('SELECT * FROM wallets WHERE user_id=?').get(req.user.id),transactions:db.prepare('SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC').all(req.user.id)})});
app.post('/api/requests/:id/offer',auth,role('provider'),(req,res)=>{const amount=Number(req.body.amount);if(!Number.isFinite(amount)||amount<=0)return res.status(400).json({error:'قيمة العرض غير صحيحة'});try{const r=db.prepare('INSERT INTO offers(request_id,provider_id,amount,note) VALUES(?,?,?,?)').run(req.params.id,req.user.id,amount,req.body.note||'');res.json({id:r.lastInsertRowid})}catch(e){res.status(409).json({error:'تم إرسال عرض لهذا الطلب بالفعل'})}});
app.get('/api/requests/:id/offers',auth,(req,res)=>res.json(db.prepare('SELECT o.*,u.name provider FROM offers o JOIN users u ON u.id=o.provider_id WHERE o.request_id=? ORDER BY o.amount').all(req.params.id)));
app.post('/api/requests/:id/assign',auth,admin,(req,res)=>{const r=db.prepare('UPDATE requests SET provider_id=?,status=CASE WHEN status=\'new\' THEN \'in_progress\' ELSE status END,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(req.body.provider_id,req.params.id);res.json({ok:r.changes>0})});
app.post('/api/requests/:id/accept',auth,role('provider'),(req,res)=>{const r=db.prepare("UPDATE requests SET provider_id=?,status='in_progress',updated_at=CURRENT_TIMESTAMP WHERE id=? AND provider_id IS NULL AND status='new'").run(req.user.id,req.params.id);res.json({ok:r.changes>0})});
app.post('/api/requests/:id/status',auth,(req,res)=>{const s=req.body.status;if(!['new','in_progress','completed','cancelled'].includes(s))return res.status(400).json({error:'حالة غير صحيحة'});let r;if(req.user.role==='admin')r=db.prepare('UPDATE requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(s,req.params.id);else r=db.prepare('UPDATE requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND provider_id=?').run(s,req.params.id,req.user.id);res.json({ok:r.changes>0})});
app.post('/api/requests/:id/rating',auth,role('customer'),(req,res)=>{const rating=Number(req.body.rating);if(!Number.isInteger(rating)||rating<1||rating>5)return res.status(400).json({error:'التقييم من 1 إلى 5'});const r=db.prepare("UPDATE requests SET rating=? WHERE id=? AND customer_id=? AND status='completed'").run(rating,req.params.id,req.user.id);res.json({ok:r.changes>0})});
app.get('/api/admin/stats',auth,admin,(req,res)=>{const one=q=>db.prepare(q).get().n;res.json({total:one('SELECT COUNT(*) n FROM requests'),open:one("SELECT COUNT(*) n FROM requests WHERE status='new'"),active:one("SELECT COUNT(*) n FROM requests WHERE status='in_progress'"),done:one("SELECT COUNT(*) n FROM requests WHERE status='completed'"),customers:one("SELECT COUNT(*) n FROM users WHERE role='customer'"),providers:one("SELECT COUNT(*) n FROM users WHERE role='provider'"),revenue:db.prepare("SELECT COALESCE(SUM(commission),0) n FROM requests WHERE payment_status='paid'").get().n})});
app.get(/.*/,(req,res)=>res.sendFile(path.join(publicDir,'index.html')));
app.get('/health',(req,res)=>res.json({ok:true,service:'halha',time:new Date().toISOString()}));
app.listen(PORT,()=>console.log(`Halha production server running on ${PORT}`));
